package com.mycompany.herencia1;

public class Docente extends Persona {
    // Guardamos el correo, rfc y clavePlaza como propios de Docente
    String correo; 
    String rfc;
    int clavePlaza;

    public Docente(String nombre, String apellidos, String domicilio, String correo, String rfc, int clavePlaza) {
        // Pasamos los 4 datos obligatorios a Persona, dejando el teléfono como texto vacío ""
        super(nombre, apellidos, domicilio, ""); 
        this.correo = correo;
        this.rfc = rfc;
        this.clavePlaza = clavePlaza;
    }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getRfc() { return rfc; }
    public void setRfc(String rfc) { this.rfc = rfc; }

    public int getClavePlaza() { return clavePlaza; }
    public void setClavePlaza(int clavePlaza) { this.clavePlaza = clavePlaza; }
}