package com.mycompany.herencia1;

import javax.swing.JOptionPane;

public class Herencia1 {

    public static void main(String[] args) {
        // ==========================================
        // SECCIÓN 1: REGISTRAR Y LISTAR ESTUDIANTE
        // ==========================================
        String numControl, nombreEst, apellidosEst, domicilioEst, telefonoEst, carreraEst;
        int semestreEst;
        char grupoEst;

        // Captura de datos del estudiante
        numControl = JOptionPane.showInputDialog("--- REGISTRO DE ESTUDIANTE ---\nNúmero de control:");
        nombreEst = JOptionPane.showInputDialog("Nombre del estudiante:");
        apellidosEst = JOptionPane.showInputDialog("Apellidos:");
        domicilioEst = JOptionPane.showInputDialog("Domicilio:");
        telefonoEst = JOptionPane.showInputDialog("Teléfono:");
        semestreEst = Integer.parseInt(JOptionPane.showInputDialog("Semestre (1-10):"));
        grupoEst = JOptionPane.showInputDialog("Grupo (A, B, C):").charAt(0);
        carreraEst = JOptionPane.showInputDialog("Carrera:");

        // Crear el objeto Estudiante
        Estudiante objEst = new Estudiante(numControl, nombreEst, apellidosEst, domicilioEst, telefonoEst, semestreEst, grupoEst, carreraEst);

        // Guardar los datos del objeto en una variable Cadena
        String registroEst = """
                             === DATOS DEL ESTUDIANTE ===
                             Num Control: """ + objEst.getNumControl() + "\n" +
                             "Nombre: " + objEst.getNombre() + "\n" +
                             "Apellidos: " + objEst.getApellidos() + "\n" +
                             "Domicilio: " + objEst.getDomicilio() + "\n" +
                             "Teléfono: " + objEst.getTelefono() + "\n" +
                             "Semestre: " + objEst.getSemestre() + "\n" +
                             "Grupo: " + objEst.getGrupo() + "\n" +
                             "Carrera: " + objEst.getCarrera();

        // Mostrar listado del estudiante
        JOptionPane.showMessageDialog(null, registroEst);


        // ==========================================
        // SECCIÓN 2: REGISTRAR Y LISTAR DOCENTE
        // ==========================================
        String nombreDoc, apellidosDoc, domicilioDoc, correoDoc, rfcDoc;
        int clavePlazaDoc;

        // Captura de datos del docente
        nombreDoc = JOptionPane.showInputDialog("--- REGISTRO DE DOCENTE ---\nNombre del docente:");
        apellidosDoc = JOptionPane.showInputDialog("Apellidos:");
        domicilioDoc = JOptionPane.showInputDialog("Domicilio:");
        correoDoc = JOptionPane.showInputDialog("Correo electrónico:");
        rfcDoc = JOptionPane.showInputDialog("RFC:");
        clavePlazaDoc = Integer.parseInt(JOptionPane.showInputDialog("Clave de plaza (10, 20, 30, 40):"));

        // Crear el objeto Docente
        Docente objDoc = new Docente(nombreDoc, apellidosDoc, domicilioDoc, correoDoc, rfcDoc, clavePlazaDoc);

        // Guardar los datos del objeto en una variable Cadena
        String registroDoc = """
                             === DATOS DEL DOCENTE ===
                             Nombre: """ + objDoc.getNombre() + "\n" +
                             "Apellidos: " + objDoc.getApellidos() + "\n" +
                             "Domicilio: " + objDoc.getDomicilio() + "\n" +
                             "Correo electrónico: " + objDoc.getCorreo() + "\n" +
                             "RFC: " + objDoc.getRfc() + "\n" +
                             "Clave de Plaza: " + objDoc.getClavePlaza();

        // Mostrar listado del docente
        JOptionPane.showMessageDialog(null, registroDoc);
    }
}