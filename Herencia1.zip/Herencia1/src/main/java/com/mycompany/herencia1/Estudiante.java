package com.mycompany.herencia1;

public class Estudiante extends Persona {
    String numControl;
    int semestre;
    char grupo;
    String carrera;

    public Estudiante(String numControl, String nombre, String apellidos, String domicilio, String telefono, int semestre, char grupo, String carrera) {
        // Le mandamos exactamente los 4 parámetros que la clase Persona te pide
        super(nombre, apellidos, domicilio, telefono); 
        this.numControl = numControl;
        this.semestre = semestre;
        this.grupo = grupo;
        this.carrera = carrera;
    }

    public void setNumControl(String numControl) { this.numControl = numControl; }
    public void setSemestre(int semestre) { this.semestre = semestre; }
    public void setGrupo(char grupo) { this.grupo = grupo; }
    public void setCarrera(String carrera) { this.carrera = carrera; }

    public String getNumControl() { return numControl; }
    public int getSemestre() { return semestre; }
    public char getGrupo() { return grupo; }
    public String getCarrera() { return carrera; }
}